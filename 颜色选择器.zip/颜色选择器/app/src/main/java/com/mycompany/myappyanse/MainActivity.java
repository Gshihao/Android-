package com.mycompany.myappyanse;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.content.ClipboardManager;
import android.view.*;
import android.net.*;

public class MainActivity extends Activity 
{
	private TextView seA;
	private TextView seR;
	private TextView seG;
	private TextView seB;
	private SeekBar sA;
	private SeekBar sR;
	private SeekBar sG;
	private SeekBar sB;
	private Context context;
	private String zA="FF",zR="FF",zG="FF",zB="FF";
	private int zaA=255,zaR=255,zaG=255,zaB=255;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
	    context=MainActivity.this;
		
		Localargb io=new Localargb();
		Agetshu(); //A
		Rgetshu();//R
		Ggetshu();//G
		Bgetshi();//B
		meena();
    }

	@Override
	public boolean onCreatePanelMenu(int featureId, Menu menu)
	{
		menu.add(1,1,1,"介绍");
		menu.add(2,2,2,"更多");
		menu.add(3,3,3,"退出");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		int id=item.getItemId();
		switch(id){
			case 1:
			    Intent intenta = new Intent();
		        intenta.setClass(MainActivity.this,Jieshao.class);
		        startActivity(intenta);
			    break;
			case 2:
				Uri uri = Uri.parse("http://whitebear.site/");		
                Intent intent  = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(intent);
				//startActivity(new Intent(MainActivity.this,Jieshao.class));
				break;
			case 3:
				this.finish();
		}
		return true;
	}

	private void meena()
	{
		//
		
	}
    public void jkl(View view){
		//复制颜色 16进制
     ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
     cm.setText("#"+zA+zR+zG+zB);
	 Toast.makeText(context,"已复制到剪切板",Toast.LENGTH_LONG).show();
	
	
	}
	public void rgba(View view ){
		ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setText(zaR+","+zaG+","+zaB+","+zaA);
		Toast.makeText(context,"已复制到剪切板",Toast.LENGTH_LONG).show();
	
	}
	private void setback()
	{
		String zong="#"+zA+zR+zG+zB;
		LinearLayout op=findViewById(R.id.mainLinearLayout1a);
		TextView kl=findViewById(R.id.mainTextView1iokj);
		kl.setText(""+zong);
		op.setBackgroundColor(Color.parseColor(zong));
		//op.setBackgroundColor(Color.parseColor(zong));
		rgbys();
	}

	private void rgbys()
	{
		TextView as=findViewById(R.id.mainTextView1iokjyu);
		as.setText("("+zaR+","+zaG+","+zaB+","+zaA+")");
	}

	private void Bgetshi()
	{
		// TODO: 获取B的值
		sB=findViewById(R.id.mainSeekBar1B);
		seB=findViewById(R.id.mainTextView1B);
		sB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

				@Override
				public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean)
				{
					// TODO: Implement this method
					zB=Localargb.getA(param1Int);
					zaB=param1Int;
					seB.setText(Localargb.getA(param1Int));
					setback();
				}

				@Override
				public void onStartTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}
			});
	}

	private void Ggetshu()
	{
		// TODO: 获取G的值
		sG=findViewById(R.id.mainSeekBar1G);
		seG=findViewById(R.id.mainTextView1G);
		sG.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

				@Override
				public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean)
				{
					// TODO: Implement this method
					zaG=param1Int;
					zG=Localargb.getA(param1Int);
					seG.setText(Localargb.getA(param1Int));
					setback();
				}

				@Override
				public void onStartTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}
			});
	}

	private void Rgetshu()
	{
		// TODO: 获取R的值
		sR=findViewById(R.id.mainSeekBar1R);
		seR=findViewById(R.id.mainTextView1R);
		sR.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

				@Override
				public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean)
				{
					// TODO: Implement this method
					zaR=param1Int;
					zR=Localargb.getA(param1Int);
					seR.setText(Localargb.getA(param1Int));
					setback();
				}

				@Override
				public void onStartTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}
			});
	}

	private void Agetshu()
	{
		//获取A的值
		sA=findViewById(R.id.mainSeekBar1A);
		seA=findViewById(R.id.mainTextView1a);
		sA.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

				@Override
				public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean)
				{
					// TODO: Implement this method
					zaA=param1Int;
					zA=Localargb.getA(param1Int);
					seA.setText(Localargb.getA(param1Int));
					setback();
				}

				@Override
				public void onStartTrackingTouch(SeekBar param1SeekBar)
				{
					//点击时
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar param1SeekBar)
				{
					// TODO: Implement this method
					
				}
			});
	}
	
}

