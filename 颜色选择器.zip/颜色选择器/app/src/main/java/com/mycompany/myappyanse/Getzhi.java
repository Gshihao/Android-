package com.mycompany.myappyanse;

public class Getzhi
{
}