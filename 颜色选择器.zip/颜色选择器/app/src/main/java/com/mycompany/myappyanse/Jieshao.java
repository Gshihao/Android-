package com.mycompany.myappyanse;
import android.os.*;
import android.app.*;
import android.webkit.*;

public class Jieshao extends Activity
{
	 @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guanyu);
		
		WebView io=new WebView(this);
		io.setWebChromeClient(new WebChromeClient(){
			
		});
		io.loadUrl("file:///android_asset/jieshao.html");
		setContentView(io);
	 }

}
