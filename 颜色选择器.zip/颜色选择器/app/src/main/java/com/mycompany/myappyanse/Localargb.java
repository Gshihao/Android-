package com.mycompany.myappyanse;
import java.util.*;

public class Localargb
{
	public static String getA(int a){
		if(a <16 ){
			return "0"+Integer.toHexString(a);
		}
		return Integer.toHexString(a);
	}
}

